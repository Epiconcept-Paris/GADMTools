# GADMTools
Bibliothèque R permettant de gérer les shapefiles GADM
